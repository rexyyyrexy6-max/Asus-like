# ============================================
# FREE FIRE LIKE TELEGRAM BOT
# Single file implementation
# ============================================

import os
import re
import json
import logging
import asyncio
from datetime import datetime
from typing import Dict, Optional, Tuple

import requests
from telegram.ext import (
    Application,
    CommandHandler,
    CallbackQueryHandler,
    ContextTypes,
    MessageHandler,
    filters,
    ChatMemberHandler
)

# ============================================
# CONFIGURATION
# ============================================
BOT_TOKEN = os.environ.get("7548994106:AAFBPGoBru3eySUhCWipFVhJxZpLPyzzXBg")
ADMIN_CHAT_ID = int(os.environ.get("8341253470", "8341253470"))  # Replace with your admin chat ID
API_KEY = os.environ.get("API_KEY", "STAR")  # Default API key

# Logging setup
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# ============================================
# CONSTANTS
# ============================================
API_BASE_URLS = {
    "ind": "http://like-api-star.vercel.app/like",
    "bd": "http://like-api-star.vercel.app/like"
}

# ============================================
# DATABASE (In-memory for demo)
# In production, use a real database like SQLite, PostgreSQL, etc.
# ============================================
user_data_db = {}
broadcast_messages = []

# ============================================
# HELPER FUNCTIONS
# ============================================
def validate_uid(uid: str) -> bool:
    """Validate if UID is numeric and has correct length."""
    return bool(re.match(r'^\d{10,12}$', uid))

def parse_like_command(text: str) -> Optional[Tuple[str, str]]:
    """
    Parse /like command.
    Returns (uid, region) or None if invalid.
    """
    parts = text.strip().split()
    if len(parts) < 2:
        return None
    
    uid = parts[1]
    region = parts[2] if len(parts) > 2 else "ind"
    
    if not validate_uid(uid):
        return None
    
    if region not in ["ind", "bd"]:
        region = "ind"
    
    return uid, region

def call_like_api(uid: str, region: str) -> Optional[Dict]:
    """Call the like API and return response."""
    url = API_BASE_URLS.get(region, API_BASE_URLS["ind"])
    params = {
        "uid": uid,
        "server_name": region,
        "key": API_KEY
    }
    
    try:
        response = requests.get(url, params=params, timeout=10)
        response.raise_for_status()
        data = response.json()
        
        # Check if response has required fields
        if "status" in data and data["status"] == 2:
            return data
        else:
            logger.warning(f"API returned status {data.get('status')} for UID {uid}")
            return None
            
    except requests.RequestException as e:
        logger.error(f"API request failed: {e}")
        return None
    except json.JSONDecodeError as e:
        logger.error(f"Invalid JSON response: {e}")
        return None

def format_like_response(data: Dict) -> str:
    """Format the API response for Telegram message."""
    nickname = data.get("PlayerNickname", "Unknown")
    uid = data.get("UID", "N/A")
    likes_before = data.get("LikesbeforeCommand", 0)
    likes_after = data.get("LikesafterCommand", 0)
    likes_given = data.get("LikesGivenByAPI", 0)
    remains = data.get("remains", "N/A")
    
    message = (
        f"❤️ *Like Status*\n"
        f"━━━━━━━━━━━━━━━━\n"
        f"👤 *Player:* {nickname}\n"
        f"🆔 *UID:* `{uid}`\n"
        f"📊 *Likes Before:* {likes_before}\n"
        f"📈 *Likes After:* {likes_after}\n"
        f"✨ *Likes Given:* {likes_given}\n"
        f"⏳ *Remaining:* {remains}\n"
        f"━━━━━━━━━━━━━━━━\n"
        f"🔄 *Status:* {'✅ Success' if likes_given > 0 else '⚠️ No likes given'}"
    )
    return message

# ============================================
# COMMAND HANDLERS
# ============================================
async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /start command."""
    user = update.effective_user
    welcome_message = (
        f"👋 *Welcome {user.first_name}!*\n\n"
        f"I'm a Free Fire Like Bot. I can help you send likes to Free Fire players.\n\n"
        f"📌 *How to use:*\n"
        f"`/like <UID> <region>`\n"
        f"Example: `/like 16426629440 ind`\n\n"
        f"🌍 *Available regions:* `ind`, `bd`\n\n"
        f"🔗 *Add me to your group* to help your community!\n"
        f"Use `/help` for more commands."
    )
    
    keyboard = [
        [InlineKeyboardButton("➕ Add to Group", url="https://t.me/RAJA_LIKE1_BOT?startgroup=true")],
        [InlineKeyboardButton("👨‍💻 Developer", url="https://t.me/brrajasrc1")],
        [InlineKeyboardButton("📢 Updates Channel", url="https://t.me/TREKOL_69")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        welcome_message,
        reply_markup=reply_markup,
        parse_mode="Markdown"
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /help command."""
    help_text = (
        "📚 *Help & Commands*\n\n"
        "🔹 `/like <UID> <region>` - Send likes to a Free Fire player\n"
        "   Example: `/like 16426629440 ind`\n\n"
        "🔹 `/start` - Show welcome message\n"
        "🔹 `/help` - Show this help message\n"
        "🔹 `/stats` - Show bot statistics (Admin only)\n"
        "🔹 `/broadcast` - Send broadcast message (Admin only)\n\n"
        "🌍 *Regions:* `ind` (India), `bd` (Bangladesh)\n\n"
        "⚠️ *Note:* Maximum 90 likes per day per UID."
    )
    await update.message.reply_text(help_text, parse_mode="Markdown")

async def like_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /like command."""
    user = update.effective_user
    chat_id = update.effective_chat.id
    
    # Check if command is used in private or group
    if update.effective_chat.type != "private":
        # In groups, check if user is admin (optional)
        pass
    
    # Parse the command
    command_text = update.message.text
    parsed = parse_like_command(command_text)
    
    if not parsed:
        await update.message.reply_text(
            "❌ *Invalid format!*\n\n"
            "Use: `/like <UID> <region>`\n"
            "Example: `/like 16426629440 ind`\n\n"
            "🌍 Regions: `ind`, `bd`",
            parse_mode="Markdown"
        )
        return
    
    uid, region = parsed
    
    # Send processing message
    processing_msg = await update.message.reply_text(
        f"⏳ Processing like request for UID `{uid}` (Region: {region})...",
        parse_mode="Markdown"
    )
    
    # Call API
    result = call_like_api(uid, region)
    
    if not result:
        await processing_msg.edit_text(
            "❌ *Failed to send likes!*\n\n"
            "Possible reasons:\n"
            "• Invalid UID\n"
            "• API server error\n"
            "• Daily limit reached (90 likes/day)\n\n"
            "Please try again later.",
            parse_mode="Markdown"
        )
        return
    
    # Format and send response
    response_message = format_like_response(result)
    await processing_msg.edit_text(
        response_message,
        parse_mode="Markdown"
    )
    
    # Log to admin
    log_message = (
        f"📊 *Like Request*\n"
        f"👤 User: {user.first_name} (ID: {user.id})\n"
        f"🆔 UID: {uid}\n"
        f"🌍 Region: {region}\n"
        f"📈 Result: {result.get('LikesGivenByAPI', 0)} likes given"
    )
    
    try:
        await context.bot.send_message(
            chat_id=ADMIN_CHAT_ID,
            text=log_message,
            parse_mode="Markdown"
        )
    except Exception as e:
        logger.error(f"Failed to send admin log: {e}")

async def stats_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /stats command (Admin only)."""
    user_id = update.effective_user.id
    
    if user_id != ADMIN_CHAT_ID:
        await update.message.reply_text("⛔ *You are not authorized to use this command.*", parse_mode="Markdown")
        return
    
    total_users = len(user_data_db)
    total_requests = sum(data.get("requests", 0) for data in user_data_db.values())
    
    stats_message = (
        f"📊 *Bot Statistics*\n"
        f"━━━━━━━━━━━━━━━━\n"
        f"👥 *Total Users:* {total_users}\n"
        f"📝 *Total Requests:* {total_requests}\n"
        f"🤖 *Bot Status:* 🟢 Online\n"
        f"⏰ *Uptime:* Continuous\n"
        f"━━━━━━━━━━━━━━━━"
    )
    await update.message.reply_text(stats_message, parse_mode="Markdown")

async def broadcast_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /broadcast command (Admin only)."""
    user_id = update.effective_user.id
    
    if user_id != ADMIN_CHAT_ID:
        await update.message.reply_text("⛔ *You are not authorized to use this command.*", parse_mode="Markdown")
        return
    
    # Get message after /broadcast command
    message_text = update.message.text.replace("/broadcast", "").strip()
    
    if not message_text:
        await update.message.reply_text(
            "❌ *Please provide a message to broadcast!*\n\n"
            "Usage: `/broadcast Your message here`",
            parse_mode="Markdown"
        )
        return
    
    # Store broadcast message
    broadcast_messages.append({
        "message": message_text,
        "timestamp": datetime.now().isoformat(),
        "sender": user_id
    })
    
    # Send confirmation to admin
    await update.message.reply_text(
        f"✅ *Broadcast message sent!*\n\n"
        f"📝 Message: {message_text}\n"
        f"📅 Sent at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        parse_mode="Markdown"
    )
    
    # Broadcast to all users (in production, get users from database)
    # For demo, we'll just send to a few users
    broadcast_count = 0
    for user_id, user_data in user_data_db.items():
        try:
            await context.bot.send_message(
                chat_id=user_id,
                text=f"📢 *Broadcast Message*\n\n{message_text}",
                parse_mode="Markdown"
            )
            broadcast_count += 1
            await asyncio.sleep(0.1)  # Avoid rate limiting
        except Exception as e:
            logger.error(f"Failed to send broadcast to {user_id}: {e}")
    
    # Send broadcast summary
    await context.bot.send_message(
        chat_id=ADMIN_CHAT_ID,
        text=f"✅ *Broadcast completed*\n\n📤 Sent to {broadcast_count} users.",
        parse_mode="Markdown"
    )

# ============================================
# GROUP MANAGEMENT
# ============================================
async def group_welcome(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Welcome message when bot is added to a group."""
    if update.effective_chat.type in ["group", "supergroup"]:
        welcome_text = (
            "🎉 *Thanks for adding me to your group!*\n\n"
            "I'm a Free Fire Like Bot. Use me to send likes!\n\n"
            "📌 *How to use:*\n"
            "`/like <UID> <region>`\n"
            "Example: `/like 16426629440 ind`\n\n"
            "🌍 Regions: `ind`, `bd`\n\n"
            "⚠️ *Note:* Only admins can use me in groups (optional)."
        )
        await update.message.reply_text(welcome_text, parse_mode="Markdown")

async def group_admin_only(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Restrict bot usage to admins in groups."""
    if update.effective_chat.type in ["group", "supergroup"]:
        user_id = update.effective_user.id
        chat_id = update.effective_chat.id
        
        # Get chat member
        try:
            chat_member = await context.bot.get_chat_member(chat_id, user_id)
            if chat_member.status not in ["administrator", "creator"]:
                await update.message.reply_text(
                    "⛔ *Only group admins can use this bot!*",
                    parse_mode="Markdown"
                )
                return False
        except Exception as e:
            logger.error(f"Failed to get chat member: {e}")
            return True  # Allow if we can't check
    return True

# ============================================
# ERROR HANDLER
# ============================================
async def error_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle errors."""
    logger.error(f"Update {update} caused error {context.error}")
    
    try:
        if update and update.effective_message:
            await update.effective_message.reply_text(
                "⚠️ *An error occurred!*\n\n"
                "Please try again later or contact the developer.",
                parse_mode="Markdown"
            )
    except Exception as e:
        logger.error(f"Failed to send error message: {e}")

# ============================================
# MAIN FUNCTION
# ============================================
def main():
    """Main function to run the bot."""
    # Create application
    application = Application.builder().token(BOT_TOKEN).build()
    
    # Add command handlers
    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("like", like_command))
    application.add_handler(CommandHandler("stats", stats_command))
    application.add_handler(CommandHandler("broadcast", broadcast_command))
    
    # Add group welcome handler (when bot is added to group)
    application.add_handler(
        MessageHandler(filters.StatusUpdate.NEW_CHAT_MEMBERS, group_welcome)
    )
    
    # Add error handler
    application.add_error_handler(error_handler)
    
    # Start the bot
    logger.info("Bot started...")
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()